package com.example.contactsproject


import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao

interface ContactDao {
    @Insert
    fun insertContact(contacts: Contact)

    @Query("SELECT * FROM contacts WHERE contactName = :name")
    fun findProduct(name: String): List<Contact>

    @Query("DELETE FROM contacts WHERE contactName = :name")
    fun deleteProduct(name: String)

    @Query("SELECT * FROM contacts")
    fun getAllProducts(): LiveData<List<Contact>>

    //THIS DOES THE ASC SORT FROM THE DATABASE
    @Query("SELECT * FROM contacts ORDER BY contactName ASC")
    fun sortAcending(): LiveData<List<Contact>>

    @Query("SELECT * FROM contacts ORDER BY contactName DESC")
    fun sortDecending(): LiveData<List<Contact>>



}