package com.example.contactsproject.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.contactsproject.Contact
import com.example.contactsproject.ContactRepository

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ContactRepository = ContactRepository(application)
    private val allProducts: LiveData<List<Contact>>?
    private val searchResults: MutableLiveData<List<Contact>>

    init {
        allProducts = repository.allProducts
        searchResults = repository.searchResults
    }
    fun insertProduct(product: Contact) {
        repository.insertProduct(product)
    }
    fun findProduct(name: String) {
        repository.findProduct(name)
    }
    fun deleteProduct(name: String) {
        repository.deleteProduct(name)
    }
    fun sortAcending(id: String){
        repository.sortAcending(id)
    }
    fun sortDecending(id: String){
        repository.sortDecending(id)
    }

    fun getSearchResults(): MutableLiveData<List<Contact>> {
        return searchResults
    }
    fun getAllProducts(): LiveData<List<Contact>>? {
        return allProducts
    }
}